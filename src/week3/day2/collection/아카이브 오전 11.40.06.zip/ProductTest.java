package week3.day2.collection;

import java.util.HashSet;

public class ProductTest {
    public static void main(String[] args) {
        Product product1 = new Product("p100", "TV", "20000");
        Product product2 = new Product("p200", "Computer", "10000");
        Product product3 = new Product("p100", "MP3", "700");
        Product product4 = new Product("p300", "Audio", "1000");
        HashSet<Product> productHashSet = new HashSet<>();
        productHashSet.add(product1);
        productHashSet.add(product2);
        productHashSet.add(product3);
        productHashSet.add(product4);
        System.out.printf("%10s%10s%10s\n","제품 ID","제품명","가격");
        System.out.println("-".repeat(30));
        for (Product p : productHashSet) {
            System.out.printf("%10s%10s%10s\n",p.getProductID(),p.getProductName(),p.getProductPrice());
        }

    }
}
