package week3.day3.iopractice;

import java.io.*;
import java.net.URL;

public class ImageIOLab {
    public static void main(String[] args) {
        try(FileReader fr = new FileReader("/Users/choijungwoo/kosa/src/week3/day3/list.txt");
            BufferedReader br = new BufferedReader(fr);) {
            String line = null;
            while (true){
                line = br.readLine();
                if (line == null) break;
                URL url = new URL(line.substring(line.indexOf(",") + 1));
                String fileName = "/Users/choijungwoo/kosa/src/week3/day3/myimage/" + line.substring(0,line.indexOf(","))+ ".jpg";
                try(InputStream is = url.openStream();
                    BufferedReader br2 = new BufferedReader(new InputStreamReader(is));
                    FileOutputStream fos = new FileOutputStream(fileName);){
                    int input = 0;
                    while (true) {
                        input = is.read();
                        if (input == -1)
                            break;
                        fos.write(input);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
