package week3.day5.practice;

public class DBInfo {
    public static final String URL = "jdbc:mysql://localhost:3306/edudb?characterEncoding=UTF-8&serverTimezone=UTC";
    public static final String USER = "root";
    public static final String PW = "1234";
}
