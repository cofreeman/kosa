package springrest.exam.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FriendModifyDto {

    private Integer id;
    private String fname;
    private Integer fage;
}
