package springrest.exam.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FriendCreateDto {

    private String fname;
    private Integer fage;
}
