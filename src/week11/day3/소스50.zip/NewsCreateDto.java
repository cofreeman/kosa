package com.example.springnews.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NewsCreateDto {

    public String writer;
    public String title;
    public String content;
}
