package com.example.springnews.model;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "NEWS")
@Setter
@Getter
@NoArgsConstructor
public class News {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int id;

    public String writer;
    public String title;
    public String content;
    @CreationTimestamp
    public LocalDateTime writedate;
    public int cnt;

    public News(String writer, String title, String content) {
        this.writer = writer;
        this.title = title;
        this.content = content;
    }

    public static News newsCreateDtoToNews(NewsCreateDto newsCreateDto) {
        return new News(newsCreateDto.getWriter(), newsCreateDto.getTitle(),newsCreateDto.getContent());
    }

    public void setNewsByNewsUpdateDto(NewsUpdateDto newsUpdateDto){
        this.content = newsUpdateDto.content;
        this.title = newsUpdateDto.title;
        this.writer = newsUpdateDto.writer;
    }
}
