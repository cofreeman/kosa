package com.example.springnews.controller;

import com.example.springnews.model.News;
import com.example.springnews.model.NewsCreateDto;
import com.example.springnews.model.NewsUpdateDto;
import com.example.springnews.repository.NewsRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
@Slf4j
public class NewsController {

    private final NewsRepository newsRepository;

    @GetMapping("/newsmain")
    public String getNewsMain(Model model, @PageableDefault(size = 10, page = 0, sort = "id", direction = Sort.Direction.ASC)Pageable pageable) {
        Page<News> newsPage = newsRepository.findAll(pageable);
        model.addAttribute("newsList", newsPage.getContent());
        model.addAttribute("page", newsPage);
        return "main";
    }

    @Transactional
    @GetMapping("/listOne")
    public String getNewsById(Model model, @RequestParam(name = "id") Integer id) {
        Optional<News> newsById = newsRepository.findById(id);
        News news = newsById.orElseThrow();
        news.setCnt(news.getCnt() + 1);
        newsRepository.save(news);
        model.addAttribute("news", newsRepository.findById(id).orElseThrow());
        return "news/updateForm";
    }

    @Transactional
    @GetMapping("/delete")
    public String deleteNewsById(@RequestParam(name = "id") Integer id) {
        newsRepository.deleteById(id);
        return "redirect:/newsmain";
    }

    @Transactional(readOnly = true)
    @GetMapping("/search")
    public String searchNewsByContent(Model model, @RequestParam(name = "content") String content,@PageableDefault(size = 10, page = 0, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {
        Page<News> newsPage = newsRepository.findAllByContentContaining(content, pageable);
        model.addAttribute("newsList", newsPage.getContent());
        model.addAttribute("page", newsPage);
        return "main";
    }

    @Transactional(readOnly = true)
    @GetMapping("/writer")
    public String getNewsByWriter(Model model, @RequestParam(name = "writer") String writer,@PageableDefault(size = 10, page = 0, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {
        Page<News> newsPage = newsRepository.findAllByWriter(writer,pageable);
        model.addAttribute("newsList", newsPage.getContent());
        model.addAttribute("page", newsPage);
        model.addAttribute("keyword","writer");
        model.addAttribute("currentWriter", writer);
        return "main";
    }

    @GetMapping("/newsCreateForm")
    public String getNewsCreateForm() {
        return "news/createForm";
    }

    @Transactional
    @PostMapping("/insert")
    public String insertNews(NewsCreateDto newsCreateDto) {
        News news = News.newsCreateDtoToNews(newsCreateDto);
        newsRepository.save(news);
        return "redirect:/newsmain";
    }

    @Transactional
    @PostMapping("/update")
    public String updateNews(NewsUpdateDto newsUpdateDto) {

        Optional<News> news = newsRepository.findById(newsUpdateDto.getId());
        News newsById = news.orElseThrow();
        newsById.setTitle(newsUpdateDto.getTitle());
        newsById.setWriter(newsUpdateDto.getWriter());
        newsById.setContent(newsUpdateDto.getContent());
        newsRepository.save(newsById);
        return "redirect:/newsmain";
    }
}
