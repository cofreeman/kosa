package com.example.springjpaedu.jpamvcexam.mainview;

import com.example.springjpaedu.jpamvcexam.model.entity.Dept;
import com.example.springjpaedu.jpamvcexam.model.entity.Emp;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class EmpDeptLab {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("entitytest");
        EntityManager em = emf.createEntityManager();

        Scanner scanner = new Scanner(System.in);
        boolean isEmp = Math.random() < 0.5;

        if (isEmp) {
            System.out.print("직원명을 입력하세요: ");
            String empName = scanner.nextLine();

            Emp emp = em.createQuery("SELECT e FROM Emp e WHERE e.eName = :name", Emp.class)
                .setParameter("name", empName)
                .getSingleResult();

            if (emp != null && emp.getDept() != null) {
                System.out.println("이 사원의 부서명: " + emp.getDept().getDName());
            } else {
                System.out.println("부서명을 찾을 수 없네요..ㅜㅜ");
            }
        } else {
            System.out.print("부서명을 입력하세요: ");
            String deptName = scanner.nextLine();

            Dept dept = em.createQuery("SELECT d FROM Dept d WHERE d.dName = :name", Dept.class)
                .setParameter("name", deptName)
                .getSingleResult();

            if (dept != null) {
                System.out.println("이 부서의 직원들 이름: ");
                for (Emp emp : dept.getEmp()) {
                    System.out.println(emp.getEName());
                }
            } else {
                System.out.println("직원을 찾을 수 없네요..ㅜㅜ");
            }
        }

        scanner.close();
        em.close();
        emf.close();
    }
}

