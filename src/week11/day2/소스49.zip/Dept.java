package com.example.springjpaedu.jpamvcexam.model.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;

@Entity
@Table(name = "DEPT")
@Getter
public class Dept {

    @Id
    @Column(name = "DEPTNO")
    public Integer deptNo;
    @Column(name = "DNAME")
    public String dName;
    @Column(name = "LOC_CODE")
    public String locCode;

    @OneToMany(mappedBy = "dept")
    public List<Emp> emp;
}
