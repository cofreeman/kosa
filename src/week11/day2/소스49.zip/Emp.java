package com.example.springjpaedu.jpamvcexam.model.entity;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;

@Entity
@Getter
@Table(name ="EMP")
public class Emp {

    @Id
    @Column(name = "EMPNO")
    public Integer empNo;

    @Column(name = "ENAME")
    public String eName;

    @Column(name = "JOB")
    public String job;

    @Column(name = "MGR")
    public Integer mgr;

    @Column(name = "HIREDATE")
    public LocalDate hireDate;
    @Column(name = "SAL")
    public Integer sal;

    @Column(name = "COMM")
    public Integer comm;

    @ManyToOne
    @JoinColumn(name="DEPTNO")
    public Dept dept;


}
