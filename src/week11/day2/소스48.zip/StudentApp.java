package com.example.springjpaedu.jpamvcexam.mainview;

import com.example.springjpaedu.jpamvcexam.controller.StudentController;
import java.util.Scanner;

public class StudentApp {

    public static void main(String[] args) {
        StudentController studentController = new StudentController();
        Scanner scanner = new Scanner(System.in);
        int menuNum;
        while (true) {
            printMenu();
            menuNum = scanner.nextInt();
            if (menuNum == 1) {
                studentController.printAll();
            } else if (menuNum == 2) {
                System.out.print("이름을 입력하세요: ");
                String name = scanner.next();

                // 점수 입력 받기
                System.out.print("점수를 입력하세요: ");
                int score = scanner.nextInt();
                scanner.nextLine();
                studentController.insert(name,score);
            } else if (menuNum == 3) {
                System.out.print("이름을 입력하세요: ");
                String name = scanner.next();
                scanner.nextLine();
                studentController.delete(name);
            } else if (menuNum == 4) {
                System.out.print("이름을 입력하세요: ");
                String name = scanner.next();

                // 점수 입력 받기
                System.out.print("점수를 입력하세요: ");
                int score = scanner.nextInt();
                scanner.nextLine();
                studentController.update(name,score);
            } else if (menuNum == 5) {
                System.out.print("이름을 입력하세요: ");
                String name = scanner.next();
                scanner.nextLine();
                studentController.printScore(name);
            } else if (menuNum == 6) {
                break;
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("처리하려는 기능을 선택하세요.");
        System.out.println("1. 학생 정보 출력");
        System.out.println("2. 학생 정보 입력");
        System.out.println("3. 학생 정보 삭제");
        System.out.println("4. 학생 정보 수정");
        System.out.println("5. 학생 정보 확인");
        System.out.println("6. 종료");
        System.out.print("입력 : ");
    }

}
