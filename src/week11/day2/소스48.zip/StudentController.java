package com.example.springjpaedu.jpamvcexam.controller;


import com.example.springjpaedu.jpamvcexam.model.dao.StudentDAO;
import com.example.springjpaedu.jpamvcexam.model.vo.Student;
import java.util.Objects;

public class StudentController {

    StudentDAO studentDao = new StudentDAO();

    public void printAll() {
        studentDao.getAllStudent().forEach(System.out::println);
    }

    public void printScore(String name) {
        Student student = studentDao.getScore(name);
        if (Objects.isNull(student)) {
            System.out.println(name + " 학생은 존재하지 않습니다.");
            return;
        }
        System.out.println(name + " 학생의 점수는 " + student.getScore() + " 입니다");
    }

    public void insert(String name, int score) {
        System.out.println(studentDao.insertStudent(name, score)?"입력 성공":"입력 실패");
    }

    public void update(String name, int score) {
        System.out.println(name + (studentDao.updateStudent(name, score)?" 학생의 점수를 변경했습니다.":" 학생은 존재하지 않습니다."));
    }

    public void delete(String name) {
        System.out.println(name + (studentDao.deleteStudent(name)?" 학생의 데이터를 삭제했습니다.":" 학생은 존재하지 않습니다."));
    }

}
