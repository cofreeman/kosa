package com.example.springjpaedu.jpamvcexam.model.dao;

import com.example.springjpaedu.jpamvcexam.model.vo.Student;
import java.util.List;
import java.util.Objects;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class StudentDAO {

    EntityManagerFactory factory = Persistence.createEntityManagerFactory("emptest");

    public List<Student> getAllStudent() {
        EntityManager em = factory.createEntityManager();
        TypedQuery<Student> query = em.createQuery("select s from Student s", Student.class);
        return query.getResultList();
    }

    public Student getScore(String name) {
        EntityManager em = factory.createEntityManager();
        TypedQuery<Student> query = em.createQuery("select s from Student s where s.name = :name", Student.class);
        query.setParameter("name", name);
        return query.getSingleResult();
    }

    public boolean insertStudent(String name, int score) {
        boolean isSuccess = false;
        EntityManager em = factory.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();

            em.persist(new Student(name, score)); // 엔티티 객체를 영속성 컨텍스트에 등록하여 데이터베이스에 삽입

            transaction.commit();
            TypedQuery<Student> query = em.createQuery("select s from Student s where s.name = :name", Student.class);
            query.setParameter("name", name);
            if (Objects.nonNull(query.getSingleResult())){
                isSuccess = true;
            }
        } catch (Exception e) {
            transaction.rollback();
        }
        return isSuccess;
    }

    public boolean updateStudent(String name, int score) {
        boolean isSuccess = false;
        EntityManager em = factory.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();

            Query query = em.createQuery("UPDATE Student s SET s.score = :score WHERE s.name = :name");
            query.setParameter("name", name);
            query.setParameter("score", score);
            int isStudentUpdated = query.executeUpdate();
            transaction.commit();
            isSuccess = isStudentUpdated == 1;
        } catch (Exception e) {
            transaction.rollback();
        }
        return isSuccess;
    }

    public boolean deleteStudent(String name) {
        boolean isSuccess = false;
        EntityManager em = factory.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();
            Query query = em.createQuery("DELETE FROM Student s WHERE s.name = :name");
            query.setParameter("name", name);
            int isStudentDeleted = query.executeUpdate();
            transaction.commit();
            if (isStudentDeleted == 1){
                isSuccess = true;
            }
        } catch (Exception e) {
            transaction.rollback();
        }
        return isSuccess;
    }
}
