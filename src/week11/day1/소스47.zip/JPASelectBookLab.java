package com.example.springjpaedu.jpamvcexam.mainview;


import com.example.springjpaedu.jpamvcexam.model.dao.JPASelectBookDAO;
import java.util.Scanner;

public class JPASelectBookLab {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        JPASelectBookDAO jpaSelectBookDAO = new JPASelectBookDAO();
        do {
            printMenu();
        } while (jpaSelectBookDAO.print(scan.nextInt()));
    }

    private static void printMenu() {
        System.out.println("1. 모두 출력하기");
        System.out.println("2. 가격이 높은 순으로 출력하기");
        System.out.println("3. 20000원 이상인 도서만 출력하기");
        System.out.println("4. id 가 3번인 도서 출력하기");
        System.out.println("5. 도서명에 '자바'또는 '스프링'를 포함하는 도서들만 출력하기");
        System.out.println("6. 분류별 도서 가격의 합을 출력하기");
        System.out.println("7. 종료");
        System.out.println();
        System.out.print("원하는 메뉴의 번호를 선택 :");
    }

}
