package com.example.springjpaedu.jpamvcexam.model.dao;

import com.example.springjpaedu.jpamvcexam.model.vo.Book;
import com.example.springjpaedu.jpamvcexam.model.vo.Meeting;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JPASelectBookDAO {
    private EntityManagerFactory factory;

    public JPASelectBookDAO() {
        super();
        factory = Persistence.createEntityManagerFactory("emptest");
    }

    public boolean print(int menuNum) {
        boolean result = false;
        if (menuNum == 1) {
            EntityManager em = factory.createEntityManager();
            TypedQuery<Book> bookTypedQuery = em.createQuery("select b from Book b", Book.class);
            bookTypedQuery.getResultList().forEach(System.out::println);
            em.close();
            result = true;
        } else if (menuNum == 2) {
            EntityManager em = factory.createEntityManager();
            TypedQuery<Book> bookTypedQuery = em.createQuery("select b from Book b order by b.price desc", Book.class);
            bookTypedQuery.getResultList().forEach(System.out::println);
            em.close();
            result = true;
        } else if (menuNum == 3) {
            EntityManager em = factory.createEntityManager();
            TypedQuery<Book> bookTypedQuery = em.createQuery("select b from Book b where b.price >= 20000", Book.class);
            bookTypedQuery.getResultList().forEach(System.out::println);
            em.close();
            result = true;
        } else if (menuNum == 4) {
            EntityManager em = factory.createEntityManager();
            System.out.println(em.find(Book.class, 3));
            em.close();
            result = true;
        } else if (menuNum == 5) {
            EntityManager em = factory.createEntityManager();
            TypedQuery<Book> bookTypedQuery = em.createQuery("select b from Book b where b.title like :bookname", Book.class);
            bookTypedQuery.setParameter("bookname","%" + (new Random().nextBoolean()?"자바":"스프링") + "%");
            bookTypedQuery.getResultList().forEach(System.out::println);
            em.close();
            result = true;
        } else if (menuNum == 6) {
            EntityManager em = factory.createEntityManager();
            Query query = em.createQuery("select sum(b.price) as price, b.kind from Book b group by b.kind");
            List<Object[]> resultList = query.getResultList();
            resultList.forEach(i -> System.out.println("분류 코드 " + i[1] + " "+ i[0]));

            em.close();
            result = true;
        } else if (menuNum == 7) {
        }
        return result;
    }

}
