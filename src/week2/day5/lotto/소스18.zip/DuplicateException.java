package week2.day5.lotto;

public class DuplicateException extends Exception{
    public DuplicateException() {
        super("중복된 로또 번호가 발생했습니다.");
    }
}
