package week2.day4.tv;

interface Rentable {
    void rent();
}
