package week2.day4.emp;

public interface Bonus {
    void incentive(int pay);
}
