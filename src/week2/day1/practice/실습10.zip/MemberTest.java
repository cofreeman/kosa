package week2.day1.practice;

class Member{
    String name;
    String account;
    String passwd;
    int birthYear;

    public Member(String name, String account, String passwd, int birthYear) {
        this.name = name;
        this.account = account;
        this.passwd = passwd;
        this.birthYear = birthYear;
    }
}
public class MemberTest {
    public static void main(String[] args) {
        Member member1 = new Member("최정우1", "jwoo1016@naver.com", "123", 1997);
        Member member2 = new Member("최정우2", "jwoo1016@naver.com", "123", 1997);
        Member member3 = new Member("최정우3", "jwoo1016@naver.com", "123", 1997);
        Member member4 = new Member("최정우4", "jwoo1016@naver.com", "123", 1997);

        Member[] members = {member1,member2,member3,member4};

        for (int i = 0; i < members.length; i++) {
            System.out.printf("회원 %d : %s(%s,%s,%s)\n",i,members[i].name,members[i].account,members[i].passwd,members[i].birthYear);
        }
    }


}
