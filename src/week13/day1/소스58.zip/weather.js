import { defineStore } from 'pinia';
import axios from 'axios';

export const useWeatherStore = defineStore('weather', {
  state: () => ({
    weatherInfo: null,
  }),
  actions: {
    async fetchWeatherInfo() {
      try {
        const response = await axios.get('http://localhost:8088/weather');
        this.weatherInfo = response.data.time; // Assuming the API response has a "time" property
      } catch (error) {
        console.error('Failed to fetch weather information:', error);
      }
    },
  },
});
