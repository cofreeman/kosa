package week8.day2;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LottoDTO {
    private int lottoNum;
    private String result;
    private String imgName;
}
