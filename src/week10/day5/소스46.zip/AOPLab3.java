package com.example.springedu.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
@Slf4j
public class AOPLab3 {

    @Pointcut("within(com.example.springedu.controller.EmpController)")
    public void EmpControllerPointCut(){

    }

    @Around("EmpControllerPointCut()")
    public void EmpControllerAroundAdvice(ProceedingJoinPoint proceedingJoinPoint){
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        try{
            proceedingJoinPoint.proceed();
        }catch (Throwable throwable){
            System.out.println(throwable);
        }
        stopWatch.stop();
        log.info(proceedingJoinPoint.getTarget().getClass() + " - 수행시간(밀리초) - " + stopWatch.getTotalTimeMillis());
        System.out.println(proceedingJoinPoint.getTarget().getClass().getPackageName());


    }

}
