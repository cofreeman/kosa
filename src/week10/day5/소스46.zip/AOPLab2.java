package com.example.springedu.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AOPLab2 {

    @Pointcut("execution(public * com.example.springedu.controller.MultiController.select_proc(..))")
    public void select_procPointCut(){

    }
    @Pointcut("execution(public * com.example.springedu.controller.MultiController.search_proc(..))")
    public void search_procPointCut(){

    }

    @Before("select_procPointCut()")
    public void select_procBeforeAdvice(JoinPoint joinPoint){
        System.out.println(joinPoint.getSignature().getName() + " 수행전");
    }
    @After("search_procPointCut()")
    public void search_procBeforeAdvice(JoinPoint joinPoint){
        System.out.println(joinPoint.getSignature().getName() + " 수행후");
    }
}
