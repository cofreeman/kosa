package week7.day5;

public interface Greeting {

    public void greet();
}
