package week7.day4;

public class Homework {
    private String homeworkName;

    public Homework(String homeworkName) {
        this.homeworkName = homeworkName;
    }

    public String getHomeworkName() {
        return homeworkName;
    }

    public void setHomeworkName(String homeworkName) {
        this.homeworkName = homeworkName;
    }
}
