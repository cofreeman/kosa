package week7.day4;

public class MorningGreetingImpl implements Greeting {

    @Override
    public void greet() {
        System.out.println("상쾌한 아침입니다.");
    }
}
