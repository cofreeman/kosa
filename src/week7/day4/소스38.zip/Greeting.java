package week7.day4;

public interface Greeting {

    public void greet();
}
