package week7.day4;

public class EveningGreetingImpl implements Greeting {

    @Override
    public void greet() {
        System.out.println("편안한 저녁되세요.");
    }
}
