package week7.day4;

public class AfternoonGreetingImpl implements Greeting {

    @Override
    public void greet() {
        System.out.println("즐거운 오후되세요.");
    }
}
