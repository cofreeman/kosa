<template>
  <div>
    <h1>최정우의 Vue 실습 페이지</h1>
  </div>
  <hr>
  <div style="display: flex">
    <div v-for="(item, index) in items" :key="index">
      <TeamCard :name="item.name" :food="item.food" :src-url="item.srcUrl" :team-num="item.teamNum"
                @delete-card="handleCardDelete(index)"></TeamCard>
    </div>
  </div>

</template>

<script setup>
import TeamCard from '@/components/TeamCard.vue';
import {ref} from 'vue'

const items = ref([
  {
    name: '최정우',
    food: '햄버거',
    srcUrl: 'img3.png',
    teamNum: 2
  }, {
    name: '김주영',
    food: '치킨',
    srcUrl: 'img2.png',
    teamNum: 2
  }, {
    name: '신다인',
    food: '고기',
    srcUrl: 'img4.jpeg',
    teamNum: 2
  }, {
    name: '김태현',
    food: '샌드위치',
    srcUrl: 'img1.jpeg',
    teamNum: 2
  },
]);
const handleCardDelete = (index) => {
  items.value.splice(index, 1);
};

</script>