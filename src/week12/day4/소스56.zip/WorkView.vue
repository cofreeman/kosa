<template>
  <div class="work">
    <h1>최정우의 Vue 실습 페이지</h1>
  </div>
  <hr />
  <TeamCard></TeamCard>
</template>

<script setup>
// @ is an alias to /src
import TeamCard from '@/components/TeamCard.vue'
</script>

<style>
.work {
  color: blue;
}
</style>
