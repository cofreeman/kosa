<template>
  <div class="card-list">
  <li v-for="item in items" :key="item.id" class="card-item">
    <div class="card" style="width: 18rem;margin: auto;">
        <img :src="item.srcUrl" class="card-img-top" width="70" height="200" alt="...">
        <div class="card-body">
            <h5 class="card-title">{{ item.name }}</h5>
            <p class="card-text">{{ item.food }}</p>
            <button class="btn btn-primary" @click="handleClick(item.teamNum)">OK</button>
        </div>
    </div>
  </li>
  </div>
</template>
<script setup>
    import { defineProps } from 'vue'; 
    const p = defineProps( {
      teamNum: {
        type: String,
        default:'2'
      },
      items: {
        type: Array,
        default: () => [
          {
            id: 1,
            name: '최정우',
            food: '햄버거',
            srcUrl: 'img3.png',
            teamNum: 2
          },
          {
            id: 2,
            name: '김주영',
            food: '치킨',
            srcUrl: 'img2.png',
            teamNum: 2
          },
          {
            id: 3,
            name: '신다인',
            food: '고기떡볶이',
            srcUrl: 'img4.jpeg',
            teamNum: 2
          },
          {
            id: 4,
            name: '김태현',
            food: '샌드위치',
            srcUrl: 'img1.jpeg',
            teamNum: 2
          }
        ]
      }
    });
    function handleClick() {
        alert(`${p.teamNum}팀 입니다~~~!!`);
    }
</script>
<style>
.card-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

.card-item {
  flex: 0 0 18rem;
  margin: 1rem;
}
</style>

