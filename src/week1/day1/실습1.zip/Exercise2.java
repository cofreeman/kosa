package day1;

public class Exercise2 {
    public static void main(String[] args) {
        int var1 = 35;
        int var2 = 10;
        System.out.println(var1 + " 를 " + var2+" 으로 나눈 결과 몫은 "+ var1/var2 +" 이고 나머지는 "+var1%var2 + " 입니다.");

    }
}
