package day1;

public class Exercise3 {
    public static void main(String[] args) {
        char name1 = '최';
        char name2 = '정';
        char name3 = '우';
        System.out.print(name1);
        System.out.print(name2);
        System.out.print(name3);
    }
}
