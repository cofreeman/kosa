package day1;

public class Exercise1 {
    public static void main(String[] args) {
        int var1 = 10;
        int var2 = 25;
        int var3 = 33;
        System.out.println("합계 : " + (var1 + var2 + var3));
        System.out.println("평균: " + ((var1 + var2 + var3)/3));
    }
}
