package week4.day2.practice;

enum TaskType {
    UPPER_CASE, LOWER_CASE, NUMBER, JAVA
}